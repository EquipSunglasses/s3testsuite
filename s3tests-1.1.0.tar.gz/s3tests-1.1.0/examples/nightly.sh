#!/usr/bin/env bash
# Example cron wrapper: run s3tests against one or more configs and keep
# dated JUnit/JSON results. Exit status is non-zero if any target failed.
#
#   0 2 * * * /usr/share/doc/s3tests/examples/nightly.sh /etc/s3tests/lab.conf /etc/s3tests/prod-ro.conf
#
# RESULTS_DIR (default /var/tmp/s3tests), KEEP_DAYS (default 30) and TIER
# (smoke, standard or full; default standard) can be overridden. After each
# run, test buckets older than two hours are swept in case a run was killed.

set -u

RESULTS_DIR="${RESULTS_DIR:-/var/tmp/s3tests}"
KEEP_DAYS="${KEEP_DAYS:-30}"
TIER="${TIER:-standard}"
STAMP=$(date +%Y%m%d-%H%M%S)
rc=0

[ $# -gt 0 ] || set -- ""
for conf in "$@"; do
    name=$(basename "${conf:-default}" .conf)
    out="$RESULTS_DIR/$name/$STAMP"
    mkdir -p "$out"
    args=(--"$TIER" --no-color --junit "$out/junit.xml" --json "$out/results.json")
    [ -n "$conf" ] && args=(-c "$conf" "${args[@]}")
    sweep=(--cleanup --older-than 120 --yes)
    [ -n "$conf" ] && sweep=(-c "$conf" "${sweep[@]}")
    if s3tests "${args[@]}" > "$out/console.log" 2>&1; then
        echo "$name: OK ($out)"
    else
        echo "$name: FAILED ($out/console.log)"
        rc=1
    fi
    s3tests "${sweep[@]}" > "$out/cleanup.log" 2>&1 || { echo "$name: leftover buckets ($out/cleanup.log)"; rc=1; }
done

find "$RESULTS_DIR" -mindepth 2 -maxdepth 2 -type d -mtime "+$KEEP_DAYS" -exec rm -rf {} + 2>/dev/null
exit $rc
