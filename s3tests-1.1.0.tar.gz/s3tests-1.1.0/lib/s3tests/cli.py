"""Command line entry point."""

import argparse
import os
import signal
import sys
import time

from . import LIBDIR, version_line, cleanup, config, report, runner, safety, selftest
from . import client as client_mod

EPILOG = """examples:
  s3tests --check                      verify endpoint, TLS and credentials
  s3tests --smoke                      21 core data-path tests, about a minute
  s3tests --standard                   140 tests: what S3 applications commonly rely on
  s3tests --full                       all 190 tests (default, or [run] tier)
  s3tests --cleanup --dry-run          list leftover test buckets
  s3tests --cleanup --yes              delete them (only names starting with bucket_prefix)
  s3tests --recover                    clean up after runs that were killed or crashed
  s3tests --max-runtime 30             abort with cleanup after 30 minutes
  s3tests multipart listing            run tests whose id contains a word
  s3tests 'object.test_range_*'        glob on test ids
  s3tests -t versioning -x slow        select or exclude by tag
  s3tests -j 8 --junit out/junit.xml   parallel run with JUnit output for CI
  s3tests -v object.test_put_get_roundtrip   traceback and HTTP history on failure

exit status: 0 all passed, 1 failures or leftover buckets, 2 usage or config error,
             3 endpoint unreachable, 4 run aborted (circuit breaker, --max-runtime), 130 interrupted
"""


def _split(values):
    out = []
    for v in values or ():
        out.extend(p.strip() for p in v.split(',') if p.strip())
    return out


def build_parser():
    p = argparse.ArgumentParser(prog='s3tests', description='S3 protocol conformance tests '
                                '(standard library only, no tox/pytest).', epilog=EPILOG,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('patterns', nargs='*', metavar='PATTERN',
                   help='test id substring or glob (module.test_name)')
    p.add_argument('-c', '--config', help='config file (default: $S3TESTS_CONF, ./s3tests.conf, '
                   '~/.s3tests.conf, /etc/s3tests/s3tests.conf)')
    p.add_argument('--endpoint', help='override [target] endpoint')
    p.add_argument('--region', help='override [target] region')
    p.add_argument('--addressing', choices=('path', 'virtual'), help='override addressing style')
    p.add_argument('--ca-bundle', help='CA bundle for TLS verification')
    p.add_argument('-k', '--insecure', action='store_true', help='do not verify TLS certificates')
    tier = p.add_mutually_exclusive_group()
    tier.add_argument('--tier', choices=runner.TIERS, help='test tier (default from [run] tier, else full)')
    tier.add_argument('--smoke', dest='tier', action='store_const', const='smoke', help='same as --tier smoke')
    tier.add_argument('--standard', dest='tier', action='store_const', const='standard',
                      help='same as --tier standard')
    tier.add_argument('--full', dest='tier', action='store_const', const='full', help='same as --tier full')
    p.add_argument('-t', '--tag', action='append', help='only run tests with any of these tags')
    p.add_argument('-x', '--exclude-tag', action='append', help='skip tests with any of these tags')
    p.add_argument('--no-default-excludes', action='store_true', help='ignore exclude_tags from the config')
    p.add_argument('-j', '--jobs', type=int, help='parallel workers (default from config, else 1)')
    p.add_argument('--junit', metavar='FILE', help='write JUnit XML results')
    p.add_argument('--json', metavar='FILE', help='write JSON results')
    p.add_argument('-v', '--verbose', action='count', default=0,
                   help='-v tracebacks and HTTP history on failure, -vv include headers')
    p.add_argument('--fail-fast', action='store_true', help='stop after the first failure')
    p.add_argument('--list', action='store_true', help='list selected tests and exit')
    p.add_argument('--list-tags', action='store_true', help='list tags with test counts and exit')
    p.add_argument('--check', action='store_true', help='check connectivity and credentials, then exit')
    p.add_argument('--show-config', action='store_true', help='print the effective configuration and exit')
    p.add_argument('--selftest', action='store_true', help='offline signer self-test (no endpoint needed)')
    p.add_argument('--cleanup', action='store_true',
                   help='delete leftover buckets whose names start with bucket_prefix, then exit')
    p.add_argument('--dry-run', action='store_true', help='with --cleanup: list, do not delete')
    p.add_argument('--older-than', type=int, metavar='MIN',
                   help='with --cleanup: only buckets created more than MIN minutes ago '
                        '(protects runs in progress)')
    p.add_argument('-y', '--yes', action='store_true', help='with --cleanup: do not ask for confirmation')
    p.add_argument('--recover', action='store_true',
                   help='remove buckets recorded by runs that died (kill -9, crash), then exit')
    p.add_argument('--no-recover', action='store_true',
                   help='do not clean up after dead runs before starting')
    p.add_argument('--max-runtime', type=int, metavar='MIN',
                   help='abort the run (with cleanup) after MIN minutes')
    p.add_argument('--no-color', action='store_true', help='disable colored output')
    p.add_argument('--version', action='store_true', help='show version, build, install path and Python, then exit')
    return p


def tls_hint(exc, cfg):
    """Explain certificate failures in terms of what to configure."""
    text = str(exc)
    if 'CERTIFICATE_VERIFY_FAILED' not in text and 'SSLCertVerification' not in type(exc).__name__:
        return ''
    host = cfg.endpoint.split('://', 1)[1].split('/')[0]
    if 'mismatch' in text or "doesn't match" in text:
        return '\n'.join(['', 'TLS verification failed: the certificate is trusted but not issued for %r.' % host,
                           'Use the hostname the certificate names (check its SAN entries), not an IP or alias.',
                           'See the names:  openssl s_client -connect %s </dev/null 2>/dev/null | openssl x509 -noout -ext subjectAltName'
                           % (host if ':' in host else host + ':443')])
    lines = ['', 'TLS verification failed. Python does not trust the CA that issued the server certificate.']
    if 'local issuer' in text:
        lines.append('Either this Python has no CA store, or a proxy is re-signing traffic with an internal CA.')
    lines += [
        'Fix: set [target] ca_bundle (or S3TESTS_CA_BUNDLE, --ca-bundle) to a PEM file containing the issuing root CA,',
        '     e.g. /etc/pki/tls/certs/ca-bundle.crt on RHEL, /etc/ssl/cert.pem on macOS, or your corporate root CA.',
        'See the issuer:  openssl s_client -connect %s:%s </dev/null 2>/dev/null | grep "i:"' % (
            cfg.endpoint.split('://', 1)[1].split('/')[0].split(':')[0],
            cfg.endpoint.split('://', 1)[1].split('/')[0].split(':')[1] if cfg.endpoint.count(':') > 1 else '443'),
        'Use -k only to confirm the diagnosis; it disables certificate checks.',
    ]
    return '\n'.join(lines)


def _check(cfg):
    ok = True
    for label, creds in (('main', cfg.main), ('alt', cfg.alt)):
        if creds is None:
            print('%-4s  not configured' % label)
            continue
        c = cfg.make_client(creds, label)
        try:
            r = c.list_buckets()
        except Exception as e:
            print('%-4s  cannot reach %s: %s: %s%s' % (label, cfg.endpoint, type(e).__name__, e, tls_hint(e, cfg)))
            return False
        if r.ok:
            owner = r.xml().findtext('Owner/ID')
            print('%-4s  OK  owner=%s  buckets=%d  (%.0f ms)' % (
                label, owner, len(r.xml().findall('Buckets/Bucket')), r.elapsed * 1000))
        else:
            print('%-4s  HTTP %d %s %s' % (label, r.status, r.error_code or '', r.error_message or ''))
            ok = False
    return ok


def main(argv=None):
    args = build_parser().parse_args(argv)
    if args.version:
        import platform
        print(version_line())
        print('library : %s' % LIBDIR)
        print('python  : %s %s' % (platform.python_version(), sys.executable))
        return 0
    if args.selftest:
        return selftest.run()

    overrides = {'endpoint': args.endpoint, 'region': args.region, 'addressing': args.addressing,
                 'ca_bundle': args.ca_bundle, 'jobs': args.jobs, 'tier': args.tier,
                 'max_runtime': args.max_runtime}
    if args.insecure:
        overrides['verify_ssl'] = False
    try:
        cfg = config.load(args.config, overrides)
    except config.ConfigError as e:
        print('s3tests: %s' % e, file=sys.stderr)
        return 2

    if not (args.list or args.list_tags or args.selftest):
        for w in cfg.warnings:
            print('warning: %s' % w, file=sys.stderr)

    tests = runner.discover()
    if args.list_tags:
        counts = {}
        for t in tests:
            for tag in t.tags:
                counts[tag] = counts.get(tag, 0) + 1
        for tag in sorted(counts):
            print('%-24s %4d' % (tag, counts[tag]))
        return 0

    include = _split(args.tag) or cfg.include_tags
    exclude = _split(args.exclude_tag) + ([] if args.no_default_excludes else cfg.exclude_tags)
    tier = cfg.tier if not args.patterns or args.tier else 'full'
    selected = runner.select(tests, args.patterns, include, exclude, tier)

    if args.list:
        for t in selected:
            print('%-58s %-9s %s' % (t.id, t.tier, ','.join(sorted(t.tags - {t.module}))))
        print('\n%d of %d tests selected (tier %s)' % (len(selected), len(tests), tier), file=sys.stderr)
        return 0

    try:
        cfg.validate()
    except config.ConfigError as e:
        print('s3tests: %s' % e, file=sys.stderr)
        return 2

    if args.show_config:
        print(cfg.describe())
        return 0
    if args.check:
        print(cfg.describe() + '\n')
        return 0 if _check(cfg) else 3
    if args.recover:
        return _recover(cfg, cfg.state_dir or safety.default_state_dir(), explicit=True)
    if args.cleanup:
        try:
            return cleanup.sweep(cfg, dry_run=args.dry_run, older_than=args.older_than,
                                 assume_yes=args.yes, jobs=max(1, cfg.jobs))
        except Exception as e:
            print('s3tests: cleanup failed: %s: %s%s' % (type(e).__name__, e, tls_hint(e, cfg)), file=sys.stderr)
            return 3

    if not selected:
        print('s3tests: no tests match the selection', file=sys.stderr)
        return 2

    try:
        r = cfg.make_client(cfg.main, 'main').list_buckets()
    except Exception as e:
        print('s3tests: cannot reach %s: %s: %s%s' % (cfg.endpoint, type(e).__name__, e, tls_hint(e, cfg)),
              file=sys.stderr)
        return 3
    if not r.ok:
        print('s3tests: preflight ListBuckets failed: HTTP %d %s %s' % (
            r.status, r.error_code or '', r.error_message or ''), file=sys.stderr)
        return 3

    state_dir = cfg.state_dir or safety.default_state_dir()
    if cfg.recover and not args.no_recover:
        _recover(cfg, state_dir)

    journal = safety.Journal(state_dir, cfg)
    if not journal.enabled:
        print('warning: cannot write run journal in %s (%s); a hard kill could leave buckets that only '
              '--cleanup will find' % (state_dir, getattr(journal, 'error', '')), file=sys.stderr)
    state = safety.RunState(cfg, journal)
    restore = _install_signal_handlers(state, journal, cfg)

    console = report.Console(color=False if args.no_color else None, verbose=args.verbose)

    def on_result(res):
        try:
            console.result(res)
        except (BrokenPipeError, IOError):
            # stdout closed (e.g. piped into head): keep cleaning up, stop printing
            _silence_stdout()
            state.abort('output closed (broken pipe)')

    def on_notice(msg):
        try:
            print('>>> %s' % msg)
            sys.stdout.flush()
        except (BrokenPipeError, IOError):
            _silence_stdout()

    try:
        console.start(len(selected), cfg, tier)
    except (BrokenPipeError, IOError):
        _silence_stdout()
    t0 = time.time()
    try:
        results = runner.run(cfg, selected, jobs=max(1, cfg.jobs), fail_fast=args.fail_fast,
                             on_result=on_result, full_trace=args.verbose >= 2, state=state,
                             on_notice=on_notice)
        if state.aborted:
            print('\nrun aborted: %s' % state.abort_reason)
        still = _final_cleanup(cfg, state, journal, results)
    finally:
        restore()
    elapsed = time.time() - t0
    console.summary(results, elapsed, state.abort_reason if state.aborted else None)
    ns = client_mod.NET_STATS
    if ns['requests']:
        print('network: %d requests over %d connections; retries: %d connect, %d stale keep-alive, '
              '%d dropped reads, %d SlowDown' % (ns['requests'], ns['connections'], ns['connect_retries'],
                                                 ns['stale_retries'], ns['read_retries'], ns['slowdown_retries']))
    hung = [r for r in results if getattr(r, 'hung', False)]
    if hung:
        print('\n%d test(s) hung and were abandoned: %s' % (len(hung), ', '.join(r.test.id for r in hung)))
    journal.close()
    if still:
        print('\n%d test bucket(s) remain on %s:' % (len(still), cfg.endpoint))
        for name, err in still:
            print('  %s: %s' % (name, err))
        if journal.enabled:
            print('they are recorded in %s and will be retried automatically on the next run,' % journal.path)
            print('or now with: s3tests --recover')
        else:
            print('remove them with: s3tests --cleanup')
    if args.junit:
        report.write_junit(args.junit, results, cfg, elapsed)
    if args.json:
        report.write_json(args.json, results, cfg, elapsed)
    if state.signal_received:
        return 130
    if state.aborted and not args.fail_fast:
        return 4
    return 1 if still or any(r.status in runner.BAD for r in results) else 0


def _final_cleanup(cfg, state, journal, results):
    """Make sure the run leaves nothing behind before it exits.

    Buckets that tests could not remove (for example because the network
    dropped) are retried with backoff for up to final_cleanup_window seconds.
    Ctrl-C, or the window running out, leaves them in the journal for the next
    run. Buckets left by earlier dead runs are cleaned here too.
    """
    def client_for(user):
        return cfg.make_client(cfg.alt if user == 'alt' and cfg.alt else cfg.main, user)

    pending = [(c, b) for r in results for b, c in r.leftovers]
    seen = set(b for _, b in pending)
    for b, user in sorted(journal.live().items()):  # e.g. tests still stuck when the run ended
        if b not in seen:
            pending.append((client_for(user), b))
    still = []
    if pending:
        print('\ncleaning up %d bucket(s) that tests could not remove:' % len(pending))
        still = cleanup.remove_buckets(cfg, pending, jobs=max(1, cfg.jobs), journal=journal)
    give_up = time.time() + cfg.final_cleanup_window
    wait = 10
    while still and time.time() < give_up and not state.signal_received:
        wait = max(1, min(wait, int(give_up - time.time())))
        print('%d bucket(s) still present; retrying in %ds (cleanup window %ds, Ctrl-C to stop waiting)'
              % (len(still), wait, cfg.final_cleanup_window))
        end = time.time() + wait
        while time.time() < end and not state.signal_received:
            time.sleep(0.2)
        if state.signal_received:
            break
        live = journal.live()
        retry = [(client_for(live.get(name, 'main')), name) for name, _ in still]
        still = cleanup.remove_buckets(cfg, retry, jobs=max(1, cfg.jobs), journal=journal)
        wait = min(wait * 2, 60)
    if cfg.recover and not state.signal_received:
        state_dir = cfg.state_dir or safety.default_state_dir()
        if safety.stale_journals(state_dir, cfg.endpoint):
            print('\nchecking for buckets left by earlier runs:')
            _recover(cfg, state_dir)
    return still


def _silence_stdout():
    devnull = open(os.devnull, 'w')
    try:
        os.dup2(devnull.fileno(), sys.stdout.fileno())
    except OSError:
        pass
    sys.stdout = devnull


def _recover(cfg, state_dir, explicit=False):
    """Clean up buckets left by runs that died (kill -9, crash, power loss)."""
    try:
        removed, failed = safety.recover(cfg, state_dir, sys.stdout, cleanup.nuke_bucket)
    except Exception as e:
        print('warning: recovery of earlier runs failed: %s: %s' % (type(e).__name__, e), file=sys.stderr)
        return 1
    if failed:
        print('warning: %d bucket(s) from earlier runs could not be removed; see above' % failed, file=sys.stderr)
    elif explicit and not removed:
        print('nothing to recover for %s' % cfg.endpoint)
    return 1 if failed else 0


def _install_signal_handlers(state, journal, cfg):
    """First Ctrl-C/SIGTERM/SIGHUP: abort and clean up. Second: exit at once."""
    state.signal_received = None
    previous = {}

    def handler(signum, frame):
        try:
            name = signal.Signals(signum).name
        except (AttributeError, ValueError):
            name = 'signal %d' % signum
        if name == 'SIGINT':
            name = 'SIGINT (Ctrl-C)'
        if state.signal_received is None:
            state.signal_received = name
            state.abort('interrupted by %s' % name)
            sys.stderr.write('\n%s: stopping new tests, letting running tests stop and clean up '
                             '(at most %ds). Press Ctrl-C again to exit immediately.\n' % (name, cfg.hang_grace))
            sys.stderr.flush()
            return
        sys.stderr.write('\nexiting immediately. ')
        live = journal.live()
        if live and journal.enabled:
            sys.stderr.write('%d bucket(s) are recorded in %s and will be removed on the next run '
                             '(or: s3tests --recover).\n' % (len(live), journal.path))
        elif live:
            sys.stderr.write('%d bucket(s) may remain; run: s3tests --cleanup\n' % len(live))
        else:
            sys.stderr.write('no test buckets were left.\n')
        sys.stderr.flush()
        os._exit(130)

    for sig in (signal.SIGINT, signal.SIGTERM, getattr(signal, 'SIGHUP', None)):
        if sig is not None:
            try:
                previous[sig] = signal.signal(sig, handler)
            except (ValueError, OSError):
                pass

    def restore():
        for sig, old in previous.items():
            signal.signal(sig, old)
    return restore

if __name__ == '__main__':
    sys.exit(main())
