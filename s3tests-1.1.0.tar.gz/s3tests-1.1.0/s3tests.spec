Name:           s3tests
Version:        1.1.0
Release:        1%{?dist}
Summary:        Dependency-free S3 protocol conformance test suite
License:        MIT
URL:            https://example.invalid/s3tests
Source0:        %{name}-%{version}.tar.gz
BuildArch:      noarch

BuildRequires:  make
BuildRequires:  sed
Requires:       bash
# Any Python 3.6+.
#  el7  (rpm 4.11, yum): no rich dependencies; python3 (3.6) is in the base
#       repo from RHEL 7.7. Build with --define 'rhel 7' or on a RHEL 7 host.
#  el8+ (rpm 4.14+, dnf/yum): RHEL 8 always has platform-python, RHEL 9/10 python3.
%if 0%{?rhel} && 0%{?rhel} < 8
Requires:       python3
BuildRequires:  python3
%else
Requires:       (python3 or platform-python)
%endif

# gzip payload and SHA-256 file digests are readable by every rpm from RHEL 7
# (4.11) on; newer build hosts would otherwise default to zstd.
%global _binary_payload w9.gzdio
%global _source_payload w9.gzdio
%global _binary_filedigest_algorithm 8
%global _source_filedigest_algorithm 8

%global debug_package %{nil}
# Pure Python run with -B straight from the data directory. Skipping the brp scripts
# avoids byte-compiling with the build host's interpreter, so the noarch RPM
# installs cleanly on every RHEL release it targets.
%global __os_install_post %{nil}

%description
s3tests exercises the S3 REST API of an on-premises object store (MinIO,
StorageGRID, ECS, and similar S3-compatible gateways): buckets, objects, listing, multipart
upload, copy, versioning, tagging, lifecycle, CORS, bucket policy, ACLs,
SigV4 and presigned URL authentication, SSE and Object Lock.

It uses only the Python standard library: no pip, tox, pytest or boto, and
no network access at install time. Results go to the console, JUnit XML
and JSON.

%prep
%setup -q

%build
# nothing to build

%install
./install.sh --prefix %{_prefix} --sysconfdir %{_sysconfdir} --destdir %{buildroot} --no-docs
# RHEL keeps the system CA bundle here rather than at the macOS path in the sample
sed -e 's|^ca_bundle = /etc/ssl/cert.pem$|ca_bundle = /etc/pki/tls/certs/ca-bundle.crt|' \
    etc/s3tests.conf.sample > %{buildroot}%{_sysconfdir}/%{name}/s3tests.conf
chmod 0600 %{buildroot}%{_sysconfdir}/%{name}/s3tests.conf

%check
S3TESTS_HOME=%{buildroot}%{_datadir}/%{name} %{buildroot}%{_bindir}/s3tests --selftest

%files
%license LICENSE
%doc README.md COVERAGE.html examples
%{_bindir}/s3tests
%{_datadir}/%{name}
%dir %{_sysconfdir}/%{name}
%config(noreplace) %attr(0600,root,root) %{_sysconfdir}/%{name}/s3tests.conf
%{_sysconfdir}/%{name}/s3tests.conf.sample

%changelog
* Tue Oct 13 2026 CTS Object Storage Engineering <objectstorage@example.invalid> - 1.1.0-1
- Tiers (smoke/standard/full), --cleanup, --recover, crash journal and watchdog
- Keep-alive connections, safe retries, pause and resume on endpoint outages
- AWS defaults (ACLs disabled, Block Public Access, SSE-C blocked) reported as SKIP
- RHEL 7 (el7) build, yum repository builder, no-RPM installer
- Version, build ID and install path shown on every run

* Fri Oct 09 2026 CTS Object Storage Engineering <objectstorage@example.invalid> - 1.0.0-1
- Initial package
