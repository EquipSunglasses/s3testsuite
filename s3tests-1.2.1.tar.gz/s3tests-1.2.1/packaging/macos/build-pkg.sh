#!/usr/bin/env bash
# Build dist/s3tests-VERSION.pkg on macOS. The package installs the same
# layout as the RPM under /usr/local:
#
#   /usr/local/bin/s3tests
#   /usr/local/share/s3tests/s3tests/...
#   /usr/local/etc/s3tests/s3tests.conf.sample
#   /usr/local/share/doc/s3tests/
#
# Uses only Xcode Command Line Tools (pkgbuild) and the system python3.
# Set SIGN_IDENTITY="Developer ID Installer: ..." to sign the package.

set -euo pipefail

[ "$(uname -s)" = "Darwin" ] || { echo "build-pkg.sh must run on macOS (pkgbuild)" >&2; exit 2; }
command -v pkgbuild >/dev/null 2>&1 || { echo "pkgbuild not found: xcode-select --install" >&2; exit 2; }

ROOT=$(cd "$(dirname "$0")/../.." && pwd -P)
VERSION=$(sed -n "s/^__version__ = '\(.*\)'/\1/p" "$ROOT/lib/s3tests/__init__.py")
STAGE=$(mktemp -d "${TMPDIR:-/tmp}/s3tests-pkg.XXXXXX")
trap 'rm -rf "$STAGE"' EXIT

"$ROOT/install.sh" --prefix /usr/local --destdir "$STAGE/root"
# Remove extended attributes and AppleDouble files that would end up in the payload.
xattr -rc "$STAGE/root" 2>/dev/null || true

mkdir -p "$ROOT/dist"
OUT="$ROOT/dist/s3tests-$VERSION.pkg"
SIGN_ARGS=()
if [ -n "${SIGN_IDENTITY:-}" ]; then SIGN_ARGS=(--sign "$SIGN_IDENTITY"); fi

pkgbuild --root "$STAGE/root" \
         --identifier "com.example.s3tests" \
         --version "$VERSION" \
         --install-location / \
         ${SIGN_ARGS[@]+"${SIGN_ARGS[@]}"} \
         "$OUT"

echo
echo "built $OUT"
echo "install:   sudo installer -pkg \"$OUT\" -target /"
echo "verify:    /usr/local/bin/s3tests --selftest"
echo "remove:    sudo $ROOT/packaging/macos/uninstall.sh"
