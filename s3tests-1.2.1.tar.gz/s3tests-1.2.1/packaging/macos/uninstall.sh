#!/usr/bin/env bash
# Kept for compatibility; the uninstaller now lives at the top of the source tree
# and is installed as <prefix>/share/s3tests/uninstall.sh.
exec "$(cd "$(dirname "$0")/../.." && pwd -P)/uninstall.sh" "$@"
