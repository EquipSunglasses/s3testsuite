#!/usr/bin/env bash
# Build yum/dnf repositories for s3tests, one per RHEL major release, plus the
# matching .repo files. Publish OUTDIR on any internal web server (or import
# the RPMs into Satellite, Pulp or Artifactory instead).
#
#   packaging/rpm/make-yum-repo.sh OUTDIR BASEURL dist/*.rpm
#   e.g. make-yum-repo.sh /srv/www/s3tests https://repo.example.internal/s3tests dist/*.noarch.rpm
#
# Layout:
#   OUTDIR/el7/  s3tests-*.el7.noarch.rpm + repodata   (RHEL/CentOS 7, yum)
#   OUTDIR/el8/  s3tests-*.el8.noarch.rpm + repodata   (RHEL 8, 9, 10, dnf/yum)
#   OUTDIR/s3tests-el7.repo, OUTDIR/s3tests-el8.repo  -> copy to /etc/yum.repos.d/
#
# el7 and el8 must stay in separate repositories: the el8 RPM uses a rich
# dependency that RHEL 7's rpm cannot read, and yum would otherwise pick the
# higher-sorting el8 build. Needs createrepo_c or createrepo.
#
# Signing (recommended for gpgcheck=1): rpm --addsign the RPMs first, publish
# the public key as OUTDIR/RPM-GPG-KEY-s3tests and pass GPGKEY=1.

set -euo pipefail

OUTDIR="${1:?usage: make-yum-repo.sh OUTDIR BASEURL RPM...}"
BASEURL="${2:?usage: make-yum-repo.sh OUTDIR BASEURL RPM...}"
shift 2
[ $# -gt 0 ] || { echo "no RPMs given" >&2; exit 2; }

CREATEREPO=$(command -v createrepo_c || command -v createrepo || true)
[ -n "$CREATEREPO" ] || { echo "createrepo_c or createrepo is required (yum/dnf install createrepo_c)" >&2; exit 2; }

BASEURL="${BASEURL%/}"
for rpm in "$@"; do
    case "$rpm" in
        *.src.rpm) continue ;;
        *.el7.noarch.rpm) dest=el7 ;;
        *.el8.noarch.rpm|*.el9.noarch.rpm|*.el10.noarch.rpm) dest=el8 ;;
        *) echo "skipping $rpm (no el7/el8 dist tag; build with build-rpm.sh --el7 or --el8)" >&2; continue ;;
    esac
    mkdir -p "$OUTDIR/$dest"
    cp -f "$rpm" "$OUTDIR/$dest/"
done

# gzip metadata: RHEL 7 yum cannot read the zstd that newer createrepo_c may default to.
COMPRESS=()
if "$CREATEREPO" --help 2>&1 | grep -q -- '--general-compress-type'; then
    COMPRESS=(--general-compress-type gz --compress-type gz)
fi

for rel in el7 el8; do
    [ -d "$OUTDIR/$rel" ] || continue
    "$CREATEREPO" --quiet ${COMPRESS[@]+"${COMPRESS[@]}"} "$OUTDIR/$rel"
    if [ "${GPGKEY:-0}" = 1 ]; then
        gpg="gpgcheck=1
gpgkey=$BASEURL/RPM-GPG-KEY-s3tests"
    else
        gpg="gpgcheck=0"
    fi
    case "$rel" in
        el7) desc="RHEL 7" ;;
        el8) desc="RHEL 8, 9 and 10" ;;
    esac
    cat > "$OUTDIR/s3tests-$rel.repo" <<EOF
# s3tests for $desc. Copy to /etc/yum.repos.d/ and run: yum install s3tests
[s3tests]
name=s3tests S3 conformance suite ($desc)
baseurl=$BASEURL/$rel/
enabled=1
$gpg
EOF
    echo "repository $OUTDIR/$rel ($(ls "$OUTDIR/$rel"/*.rpm | wc -l | tr -d ' ') RPM), client file $OUTDIR/s3tests-$rel.repo"
done
