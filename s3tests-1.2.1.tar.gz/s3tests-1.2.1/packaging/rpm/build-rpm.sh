#!/usr/bin/env bash
# Build the s3tests noarch RPMs and SRPM from a `make dist` tarball.
#
#   packaging/rpm/build-rpm.sh [--srpm-only] [--el7 | --el8] dist/s3tests-X.Y.Z.tar.gz
#
#   (default)  build for the RHEL release of this host (el8 rules on non-RHEL hosts)
#   --el7      RHEL 7 / CentOS 7 RPM for yum and rpm 4.11: plain `Requires: python3`
#   --el8      RHEL 8, 9 and 10 RPM: `Requires: (python3 or platform-python)`
#
# The payload is identical; only the dependency header and dist tag differ.
# Output lands next to the tarball. Uses a private rpmbuild tree.

set -euo pipefail

SRPM_ONLY=0
DEFS=()
while [ $# -gt 1 ]; do
    case "$1" in
        --srpm-only) SRPM_ONLY=1 ;;
        --el7) DEFS=(--define "rhel 7" --define "dist .el7") ;;
        --el8) DEFS=(--define "rhel 8" --define "dist .el8") ;;
        *) echo "unknown option $1" >&2; exit 2 ;;
    esac
    shift
done
TARBALL="${1:?usage: build-rpm.sh [--srpm-only] [--el7|--el8] path/to/s3tests-VERSION.tar.gz}"

command -v rpmbuild >/dev/null 2>&1 || { echo "rpmbuild not found (yum/dnf install rpm-build)" >&2; exit 2; }

OUT=$(cd "$(dirname "$TARBALL")" && pwd -P)
TOP=$(mktemp -d "${TMPDIR:-/tmp}/s3tests-rpm.XXXXXX")
trap 'rm -rf "$TOP"' EXIT

if [ "$SRPM_ONLY" = 1 ]; then MODE=-ts; else MODE=-ta; fi
rpmbuild "$MODE" ${RPMBUILD_EXTRA:-} --define "_topdir $TOP" ${DEFS[@]+"${DEFS[@]}"} "$TARBALL"

find "$TOP/RPMS" "$TOP/SRPMS" -name '*.rpm' -exec cp {} "$OUT/" \; 2>/dev/null || true
echo
ls -1 "$OUT"/*.rpm
