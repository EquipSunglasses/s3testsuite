#!/usr/bin/env bash
# Install s3tests into a prefix without a package manager. Also used by the
# RPM spec and the macOS .pkg builder. Works with bash 3.2 (macOS) and later.
#
#   ./install.sh                         -> /usr/local, config /usr/local/etc/s3tests (run as root)
#   ./install.sh --user                  -> ~/.local, config ~/.s3tests.conf (no root needed)
#   ./install.sh --prefix /opt/s3tests   -> self-contained tree, config /opt/s3tests/etc/s3tests
#   ./install.sh --prefix /usr --sysconfdir /etc --destdir "$RPM_BUILD_ROOT" --no-docs   (packaging)
#
# Needs only bash, coreutils, sed and find, plus Python 3.6+ at run time.

set -euo pipefail

PREFIX=/usr/local
SYSCONFDIR=""
DESTDIR=""
DOCS=1
USER_MODE=0
CREATE_CONFIG=1

usage() { sed -n '2,10p' "$0" | sed 's/^# \{0,1\}//'; }

while [ $# -gt 0 ]; do
    case "$1" in
        --prefix) PREFIX="$2"; shift 2 ;;
        --prefix=*) PREFIX="${1#*=}"; shift ;;
        --sysconfdir) SYSCONFDIR="$2"; shift 2 ;;
        --sysconfdir=*) SYSCONFDIR="${1#*=}"; shift ;;
        --destdir) DESTDIR="$2"; shift 2 ;;
        --destdir=*) DESTDIR="${1#*=}"; shift ;;
        --user) USER_MODE=1; PREFIX="$HOME/.local"; shift ;;
        --no-docs) DOCS=0; shift ;;
        --no-config) CREATE_CONFIG=0; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "install.sh: unknown option $1" >&2; usage >&2; exit 2 ;;
    esac
done

if [ -z "$SYSCONFDIR" ]; then
    if [ "$PREFIX" = "/usr" ]; then SYSCONFDIR=/etc; else SYSCONFDIR="$PREFIX/etc"; fi
fi

SRC=$(cd "$(dirname "$0")" && pwd -P)
PKGDATADIR="$PREFIX/share/s3tests"
BINDIR="$PREFIX/bin"
DOCDIR="$PREFIX/share/doc/s3tests"

# --- checks for direct installs (skipped when staging into DESTDIR) ---------
if [ -z "$DESTDIR" ]; then
    if [ "$PREFIX" = "/usr" ] && command -v rpm >/dev/null 2>&1 && rpm -q s3tests >/dev/null 2>&1; then
        echo "install.sh: the s3tests RPM is installed and owns /usr; upgrade it with yum/dnf or pick another --prefix" >&2
        exit 1
    fi
    if ! { mkdir -p "$PREFIX" 2>/dev/null && [ -w "$PREFIX" ]; }; then
        echo "install.sh: cannot write to $PREFIX; run as root, or use --user or --prefix DIR" >&2
        exit 1
    fi
    PY=""
    for cand in python3 /usr/libexec/platform-python /usr/bin/python3; do
        if command -v "$cand" >/dev/null 2>&1 && \
           "$cand" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 6) else 1)' >/dev/null 2>&1; then
            PY=$(command -v "$cand"); break
        fi
    done
    if [ -z "$PY" ]; then
        echo "warning: no Python 3.6+ found; s3tests needs python3 (RHEL 7.7+: yum install python3; RHEL 9/10 built in)," >&2
        echo "         platform-python (RHEL 8, built in), or rh-python36/38 from Software Collections (older RHEL 7)" >&2
    fi
fi

PREVIOUS=""
if [ -z "$DESTDIR" ] && [ -f "$PKGDATADIR/s3tests/__init__.py" ]; then
    PREVIOUS=$(sed -n "s/^__version__ = '\(.*\)'/\1/p" "$PKGDATADIR/s3tests/__init__.py")
    if [ -f "$PKGDATADIR/s3tests/_build.py" ]; then
        PREVIOUS="$PREVIOUS (build $(sed -n "s/^BUILD = '\(.*\)'/\1/p" "$PKGDATADIR/s3tests/_build.py"))"
    fi
fi
NEW=$(sed -n "s/^__version__ = '\(.*\)'/\1/p" "$SRC/lib/s3tests/__init__.py")
if [ -f "$SRC/lib/s3tests/_build.py" ]; then
    NEW="$NEW (build $(sed -n "s/^BUILD = '\(.*\)'/\1/p" "$SRC/lib/s3tests/_build.py"))"
fi

# --- library, launcher, sample config, docs ----------------------------------
# Replace the library wholesale so modules removed upstream do not linger.
rm -rf "$DESTDIR$PKGDATADIR/s3tests"
(cd "$SRC/lib" && find s3tests -name '*.py' -type f) | sort | while read -r f; do
    mkdir -p "$DESTDIR$PKGDATADIR/$(dirname "$f")"
    install -m 0644 "$SRC/lib/$f" "$DESTDIR$PKGDATADIR/$f"
done
install -m 0755 "$SRC/uninstall.sh" "$DESTDIR$PKGDATADIR/uninstall.sh"

mkdir -p "$DESTDIR$BINDIR"
sed -e "s|@LIBDIR@|$PKGDATADIR|g" "$SRC/bin/s3tests" > "$DESTDIR$BINDIR/s3tests"
chmod 0755 "$DESTDIR$BINDIR/s3tests"

mkdir -p "$DESTDIR$SYSCONFDIR/s3tests"
install -m 0644 "$SRC/etc/s3tests.conf.sample" "$DESTDIR$SYSCONFDIR/s3tests/s3tests.conf.sample"

if [ "$DOCS" = 1 ]; then
    mkdir -p "$DESTDIR$DOCDIR/examples"
    install -m 0644 "$SRC/README.md" "$SRC/LICENSE" "$SRC/COVERAGE.html" "$DESTDIR$DOCDIR/"
    install -m 0755 "$SRC"/examples/*.sh "$DESTDIR$DOCDIR/examples/"
fi

# --- a private config to edit (direct installs only) -------------------------
CONF=""
if [ -z "$DESTDIR" ] && [ "$CREATE_CONFIG" = 1 ]; then
    if [ "$USER_MODE" = 1 ]; then CONF="$HOME/.s3tests.conf"; else CONF="$SYSCONFDIR/s3tests/s3tests.conf"; fi
    if [ ! -e "$CONF" ]; then
        # Point ca_bundle at this OS's system CA bundle.
        CA=/etc/ssl/cert.pem
        for c in /etc/pki/tls/certs/ca-bundle.crt /etc/ssl/cert.pem /etc/ssl/certs/ca-certificates.crt; do
            if [ -f "$c" ]; then CA="$c"; break; fi
        done
        (umask 077; sed -e "s|^ca_bundle = /etc/ssl/cert.pem\$|ca_bundle = $CA|" \
            "$SRC/etc/s3tests.conf.sample" > "$CONF")
        echo "created $CONF (mode 600, ca_bundle = $CA); fill in endpoint, access_key, secret_key"
    else
        echo "kept existing $CONF"
    fi
fi

if [ -n "$PREVIOUS" ]; then
    echo "upgraded s3tests $PREVIOUS -> $NEW in $DESTDIR$PREFIX"
else
    echo "installed s3tests $NEW to $DESTDIR$PREFIX"
fi
if [ -z "$DESTDIR" ]; then
    echo "  run:        $BINDIR/s3tests --selftest"
    echo "  uninstall:  $PKGDATADIR/uninstall.sh --prefix $PREFIX"
    # Another s3tests earlier on PATH would run instead of this one.
    FIRST=$(command -v s3tests 2>/dev/null || true)
    if [ -n "$FIRST" ] && [ "$FIRST" != "$BINDIR/s3tests" ]; then
        echo "  WARNING: 's3tests' on your PATH is $FIRST, not $BINDIR/s3tests."
        echo "           Running 's3tests' starts that other copy. Remove it, or run $BINDIR/s3tests."
        echo "           Check which copy runs with: s3tests --version"
    fi
    for other in /usr/bin/s3tests /usr/local/bin/s3tests "$HOME/.local/bin/s3tests" /opt/s3tests/bin/s3tests; do
        if [ "$other" != "$BINDIR/s3tests" ] && [ -x "$other" ]; then
            echo "  note: another s3tests install exists at $other ($("$other" --version 2>/dev/null | head -1 || echo 'older version'))"
        fi
    done
    case ":$PATH:" in
        *":$BINDIR:"*) ;;
        *) echo "  note: $BINDIR is not on PATH; add it, e.g. echo 'export PATH=\"$BINDIR:\$PATH\"' >> ~/.bashrc" ;;
    esac
fi
exit 0
